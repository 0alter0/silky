chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id || !tab?.url) return;

  chrome.cookies.getAll({ url: tab.url }, (cookies) => {
    if (!cookies || !cookies.length) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => alert("No cookies found in this site.")
      });
      return;
    }

    const cookieStr = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (text) => {
        navigator.clipboard.writeText(text).then(() => {
          alert("Cookies copied to clipboard");
        }).catch(() => {
          alert("Failed to copy cookies to clipboard. Try again.");
        });
      },
      args: [cookieStr]
    });
  });
});
